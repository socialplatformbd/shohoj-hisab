// চালানো: npx tsx scripts/test-logic.ts
import "fake-indexeddb/auto";
import assert from "node:assert/strict";
import { formatMoney, parseAmountToPaisa, numberToPaisa, percentOf } from "../src/lib/money";
import { addDays, endOfMonth, startOfWeek, todayDhaka, isValidIsoDate, BN_MONTHS_SHORT, EN_MONTHS_SHORT } from "../src/lib/dates";
import { budgetStatuses, debtTotals, sumTx, categoryBreakdown, summarizeDebt, monthlySeries } from "../src/lib/calc";
import { normalizeStartDay, periodKeyOf, periodRange } from "../src/lib/dates";
import { parseLocalText } from "../src/lib/localParser";
import { DEFAULT_CATEGORIES, db, newId, eraseAllData } from "../src/lib/db";
import { buildBackup, validateBackupText, restoreBackup, BackupError, encryptedBackupBlob } from "../src/lib/backup";
import { DecryptError, decryptText, encryptText, isEncryptedBackupText } from "../src/lib/cryptoBackup";
import { transactionsToCsv, parseTransactionsCsv } from "../src/lib/csv";
import { ExtractResponseSchema } from "../src/lib/aiSchema";
import { localAnswer, buildFacts } from "../src/lib/insights";
import { goalProgress } from "../src/lib/goals";
import { upcomingReminders, nextRecurringDate } from "../src/lib/reminders";
import { messCarryChain } from "../src/lib/mess";
import { costBasis, cogsOf, shopProfitAvg, topProducts, oldestDue, dueAgeDays } from "../src/lib/shopAnalytics";
import { dueOccurrences, defaultStartMonth, generateRecurring, occurrenceId, scheduledDate } from "../src/lib/recurring";
import { PIN_RE, hashPin, makeSalt, normalizePin, verifyPin } from "../src/lib/pin";
import { accountSummary } from "../src/lib/accounts";
import { allocate, messSummary, mealId, messBudgetStatus, messCostBreakdown } from "../src/lib/mess";
import { paidOf, creditOf, partyBalances, shopSummary, shopEntryValid } from "../src/lib/shop";
import { parseAmountOrZero } from "../src/lib/money";
import { goalProgress } from "../src/lib/goals";
import { upcomingReminders, nextRecurringDate } from "../src/lib/reminders";
import { messCarryChain } from "../src/lib/mess";
import { shopProfitAvg, costBasis, cogsOf, topProducts, oldestDue, dueAgeDays } from "../src/lib/shopAnalytics";
import { buildFacts } from "../src/lib/insights";
import { parseQty, parseQtyOrZero, formatQty, lineTotal, stockSummary, MAX_QTY } from "../src/lib/products";
import { markReceived, undoReceived, isPending, isReceived, pendingTotal, reimbursementIncomeId, REIMBURSEMENT_CATEGORY_ID } from "../src/lib/reimburse";
import type { Transaction, Debt, Repayment, Budget, Recurring, Account, Transfer, MessEntry, MessMeal, MessMember, ShopEntry, ShopParty, ShopProduct, ShopAdjustment, Goal } from "../src/lib/types";

let n = 0;
const ok = (name: string, fn: () => void | Promise<void>) =>
  Promise.resolve(fn()).then(() => console.log("  ✓", name), (e) => { console.error("  ✗", name, "\n", e); process.exitCode = 1; }).finally(() => n++);

const tx = (p: Partial<Transaction>): Transaction => ({ id: newId(), type: "expense", amount: 100, categoryId: "cat_food", date: "2026-05-10", createdAt: 1, updatedAt: 1, ...p });

(async () => {
  console.log("টাকা");
  await ok("parse amounts (bn/en digits, commas)", () => {
    assert.equal(parseAmountToPaisa("১,৫০০"), 150000);
    assert.equal(parseAmountToPaisa("1500.5"), 150050);
    assert.equal(parseAmountToPaisa("0.1"), 10);
    assert.equal(parseAmountToPaisa("0"), null);
    assert.equal(parseAmountToPaisa("-5"), null);
    assert.equal(parseAmountToPaisa("1.234"), null);
    assert.equal(parseAmountToPaisa("abc"), null);
    assert.equal(parseAmountToPaisa("1e5"), null);
    assert.equal(numberToPaisa(0.1 + 0.2), 30);
  });
  await ok("format money", () => {
    assert.equal(formatMoney(150000, "bn"), "৳ ১,৫০০.০০");
    assert.equal(formatMoney(150000, "en"), "৳ 1,500.00");
    assert.equal(formatMoney(12345678900, "en"), "৳ 12,34,56,789.00");
    assert.equal(formatMoney(-5, "en"), "-৳ 0.05");
    assert.equal(percentOf(1, 3), 33);
  });
  console.log("তারিখ");
  await ok("dates", () => {
    assert.ok(isValidIsoDate(todayDhaka()));
    assert.equal(addDays("2026-02-28", 1), "2026-03-01");
    assert.equal(endOfMonth("2024-02-10"), "2024-02-29");
    assert.equal(startOfWeek("2026-05-15"), "2026-05-09"); // শুক্রবার → আগের শনিবার
    assert.equal(startOfWeek("2026-05-16"), "2026-05-16"); // শনিবার
    assert.ok(!isValidIsoDate("2026-02-30"));
  });
  await ok("ছোট মাসের নাম (বাংলা যুক্তাক্ষর কাটা হয় না)", () => {
    assert.equal(BN_MONTHS_SHORT.length, 12);
    assert.equal(EN_MONTHS_SHORT.length, 12);
    assert.ok(BN_MONTHS_SHORT.every((m) => m.length > 0 && !m.endsWith("\u09CD")));
  });

  console.log("হিসাব (আয়/খরচ/ড্যাশবোর্ড/রিপোর্ট)");
  const txs = [
    tx({ type: "income", amount: 5000000, categoryId: "cat_salary" }),
    tx({ amount: 50000 }),
    tx({ amount: 8000, categoryId: "cat_transport" }),
    tx({ amount: 12000 }),
    tx({ type: "saving", amount: 100000, categoryId: "cat_saving" }),
    tx({ type: "withdraw", amount: 20000, categoryId: "cat_withdraw" }),
    tx({ amount: 99900, date: "2026-04-30" }),
  ];
  await ok("totals", () => {
    const s = sumTx(txs);
    assert.equal(s.income, 5000000);
    assert.equal(s.expense, 50000 + 8000 + 12000 + 99900);
    assert.equal(s.savings, 80000);
    assert.equal(s.balance, 5000000 - 169900 - 100000 + 20000);
  });
  await ok("category breakdown", () => {
    const b = categoryBreakdown(txs.filter((t) => t.date.startsWith("2026-05")), "expense");
    assert.equal(b[0].categoryId, "cat_food");
    assert.equal(b[0].total, 62000);
    assert.equal(b[0].percent, 88);
  });
  await ok("budget", () => {
    const budgets: Budget[] = [
      { id: "b1", month: "2026-05", categoryId: null, amount: 100000, createdAt: 1, updatedAt: 1 },
      { id: "b2", month: "2026-05", categoryId: "cat_food", amount: 60000, createdAt: 1, updatedAt: 1 },
    ];
    const st = budgetStatuses(budgets, txs, "2026-05");
    const overall = st.find((s) => s.budget.id === "b1")!;
    assert.equal(overall.spent, 70000);
    assert.equal(overall.remaining, 30000);
    assert.equal(overall.percent, 70);
    assert.equal(overall.level, "ok");
    const food = st.find((s) => s.budget.id === "b2")!;
    assert.equal(food.spent, 62000);
    assert.equal(food.level, "over");
  });
  await ok("debts & repayments", () => {
    const d: Debt = { id: "d1", person: "রহিম", amount: 100000, kind: "lent", date: "2026-05-01", dueDate: "2026-05-05", createdAt: 1, updatedAt: 1 };
    const d2: Debt = { id: "d2", person: "করিম", amount: 50000, kind: "borrowed", date: "2026-05-01", createdAt: 1, updatedAt: 1 };
    const reps: Repayment[] = [
      { id: "r1", debtId: "d1", amount: 30000, date: "2026-05-02", createdAt: 1 },
      { id: "r2", debtId: "d1", amount: 20000, date: "2026-05-03", createdAt: 2 },
    ];
    const s = summarizeDebt(d, reps, "2026-05-10");
    assert.equal(s.paid, 50000);
    assert.equal(s.remaining, 50000);
    assert.equal(s.status, "partial");
    assert.ok(s.overdue);
    const tot = debtTotals([d, d2], reps, "2026-05-10");
    assert.equal(tot.receivable, 50000);
    assert.equal(tot.payable, 50000);
    reps.push({ id: "r3", debtId: "d1", amount: 50000, date: "2026-05-04", createdAt: 3 });
    assert.equal(summarizeDebt(d, reps, "2026-05-10").status, "paid");
  });

  console.log("AI (স্থানীয় ফলব্যাক পার্সার ও স্কিমা)");
  const cats = DEFAULT_CATEGORIES;
  await ok("বাংলা বাক্য থেকে ৩টি খরচ", () => {
    const rows = parseLocalText("আজ বাজারে ৫০০ টাকা, রিকশা ভাড়া ৮০ টাকা আর দুপুরে খাবারে ১২০ টাকা খরচ করেছি।", cats, "2026-05-10");
    console.log("    →", rows.map((r) => `${r.title}:${r.amount / 100}:${r.categoryId}`).join(" | "));
    assert.equal(rows.length, 3);
    assert.deepEqual(rows.map((r) => r.amount), [50000, 8000, 12000]);
    assert.deepEqual(rows.map((r) => r.title), ["বাজার", "রিকশা ভাড়া", "দুপুরের খাবার"]);
    assert.ok(rows.every((r) => r.type === "expense" && r.date === "2026-05-10"));
    assert.deepEqual(rows.map((r) => r.categoryId), ["cat_food", "cat_transport", "cat_food"]);
  });
  await ok("আয় চিহ্নিত", () => {
    const rows = parseLocalText("আজ বেতন পেয়েছি ২৫০০০ টাকা", cats, "2026-05-10");
    assert.equal(rows.length, 1);
    assert.equal(rows[0].type, "income");
    assert.equal(rows[0].categoryId, "cat_salary");
  });
  await ok("কোনো অঙ্ক নেই → খালি", () => assert.equal(parseLocalText("আজ কিছু হয়নি", cats, "2026-05-10").length, 0));
  await ok("৳ চিহ্নসহ পুরো সংখ্যা (৳৫০০ → ৫০০, ৫ নয়)", () => {
    const r = parseLocalText("৳৫০০ চা", cats, "2026-05-10");
    assert.equal(r.length, 1);
    assert.equal(r[0].amount, 50000);
    assert.equal(parseLocalText("৳ 1,200.50 বাজার", cats, "2026-05-10")[0].amount, 120050);
  });
  await ok("ইংরেজি বাক্যে একই লেবেল দুইবার আসে না", () => {
    const r = parseLocalText("500 tk lunch and 200 tk bus", cats, "2026-05-10");
    assert.deepEqual(r.map((x) => x.title), ["lunch", "bus"]);
    assert.deepEqual(r.map((x) => x.categoryId), ["cat_food", "cat_transport"]);
  });
  await ok("আয় ও খরচ মেশানো বাক্যে ধরন আলাদা", () => {
    const r = parseLocalText("বেতন পেয়েছি ২৫০০০ টাকা এবং বাজার ৫০০ টাকা", cats, "2026-05-10");
    assert.deepEqual(r.map((x) => x.type), ["income", "expense"]);
  });
  await ok("AI আউটপুট স্কিমা কঠোর", () => {
    assert.ok(ExtractResponseSchema.safeParse({ items: [{ type: "expense", title: "বাজার", amount: 500, categoryId: "cat_food", date: "2026-05-10" }] }).success);
    assert.ok(!ExtractResponseSchema.safeParse({ items: [{ type: "expense", title: "বাজার", amount: -5 }] }).success);
    assert.ok(!ExtractResponseSchema.safeParse({ items: [{ type: "gift", title: "x", amount: 5 }] }).success);
    assert.ok(!ExtractResponseSchema.safeParse({ items: [{ type: "expense", title: "x", amount: "500" }] }).success);
    assert.ok(!ExtractResponseSchema.safeParse({ items: [{ type: "expense", title: "x", amount: 5, date: "2026-13-40" }] }).success);
    assert.ok(!ExtractResponseSchema.safeParse({ foo: 1 }).success);
  });
  await ok("প্রশ্নের স্থানীয় উত্তর (সবচেয়ে বেশি খরচ)", () => {
    const ans = localAnswer("এই মাসে আমার সবচেয়ে বেশি খরচ কোন খাতে হয়েছে?", { transactions: txs, categories: cats, budgets: [], debts: [], repayments: [] }, "2026-05-20", "bn", "bn");
    console.log("    →", ans);
    assert.ok(ans && ans.includes("খাবার") && ans.includes("৬২০.০০"));
  });

  console.log("CSV");
  await ok("export → import round trip", () => {
    const withText = [tx({ description: 'বাজার, "কাঁচা" সবজি', note: "=1+1", amount: 12345 })];
    const csv = transactionsToCsv(withText, cats);
    assert.ok(csv.includes("'=1+1"));
    const r = parseTransactionsCsv(csv, cats, 5);
    assert.equal(r.bad, 0);
    assert.equal(r.transactions.length, 1);
    assert.equal(r.transactions[0].amount, 12345);
    assert.equal(r.transactions[0].description, 'বাজার, "কাঁচা" সবজি');
    assert.equal(r.transactions[0].note, "=1+1");
    const bad = parseTransactionsCsv("date,type,category,amount\n2026-05-01,expense,খাবার,-5\n2026-05-01,expense,খাবার,50\n", cats, 5);
    assert.equal(bad.bad, 1);
    assert.equal(bad.transactions.length, 1);
  });

  await ok("CSV: একই নতুন খাত বারবার তৈরি হয় না", () => {
    const long = "ক".repeat(60);
    const r = parseTransactionsCsv(`date,type,category,amount\n2026-05-01,expense,${long},10\n2026-05-02,expense,${long},20\n2026-05-03,expense,Zakat,5\n2026-05-04,expense,zakat,5\n`, cats, 5);
    assert.equal(r.newCategories.length, 2);
    assert.equal(r.transactions.length, 4);
  });

  console.log("IndexedDB: যোগ/সম্পাদনা/মুছা, ব্যাকআপ ও রিস্টোর");
  await db.open();
  await ok("ডিফল্ট খাত seed হয়েছে", async () => assert.equal(await db.categories.count(), DEFAULT_CATEGORIES.length));
  const a = tx({ amount: 11100, description: "চা" });
  await ok("add / edit / delete", async () => {
    await db.transactions.add(a);
    assert.equal((await db.transactions.get(a.id))?.amount, 11100);
    await db.transactions.put({ ...a, amount: 22200, updatedAt: 99 });
    assert.equal((await db.transactions.get(a.id))?.amount, 22200);
    await db.transactions.delete(a.id);
    assert.equal(await db.transactions.count(), 0);
  });
  const d: Debt = { id: "dd", person: "সালমা", amount: 70000, kind: "lent", date: "2026-05-01", createdAt: 1, updatedAt: 1 };
  await db.transactions.bulkAdd(txs);
  await db.debts.add(d);
  await db.repayments.add({ id: "rr", debtId: "dd", amount: 20000, date: "2026-05-02", createdAt: 2 });
  await db.budgets.add({ id: "bb", month: "2026-05", categoryId: null, amount: 90000, createdAt: 1, updatedAt: 1 });
  await db.settings.put({ key: "userName", value: "রাকিব" });
  await db.settings.put({ key: "welcomeDone", value: true });
  let text = "";
  await ok("ব্যাকআপ তৈরি ও যাচাই", async () => {
    const b = await buildBackup();
    text = JSON.stringify(b);
    assert.equal(b.version, 1);
    assert.equal(b.data.transactions.length, txs.length);
    assert.ok(!b.data.settings.some((s) => s.key === "welcomeDone"));
    const v = validateBackupText(text);
    assert.equal(v.data.debts.length, 1);
  });
  await ok("ত্রুটিপূর্ণ ব্যাকআপ প্রত্যাখ্যাত", () => {
    const rej = (s: string, code = "invalid") => assert.throws(() => validateBackupText(s), (e: unknown) => e instanceof BackupError && e.code === code);
    rej("not json");
    rej("{}");
    rej(JSON.stringify({ app: "other", version: 1 }));
    rej(JSON.stringify({ ...JSON.parse(text), version: 99 }), "newer");
    const j = JSON.parse(text);
    j.data.transactions[0].amount = -5;
    rej(JSON.stringify(j));
    const j2 = JSON.parse(text);
    j2.data.transactions[0].categoryId = "nope";
    rej(JSON.stringify(j2));
    const j3 = JSON.parse(text);
    j3.data.repayments[0].amount = 999999999;
    rej(JSON.stringify(j3));
    const j4 = JSON.parse(text);
    j4.data.transactions.push(j4.data.transactions[0]);
    rej(JSON.stringify(j4));
  });
  await ok("রিস্টোর: ডেটা মুছে ফিরিয়ে আনা", async () => {
    await eraseAllData();
    await db.settings.clear();
    assert.equal(await db.transactions.count(), 0);
    await restoreBackup(validateBackupText(text));
    assert.equal(await db.transactions.count(), txs.length);
    assert.equal(await db.debts.count(), 1);
    assert.equal(await db.repayments.count(), 1);
    assert.equal(await db.budgets.count(), 1);
    assert.equal((await db.settings.get("userName"))?.value, "রাকিব");
    const again = await buildBackup();
    assert.equal(JSON.stringify(again.data.transactions.sort((x, y) => x.id.localeCompare(y.id))), JSON.stringify(JSON.parse(text).data.transactions.sort((x: Transaction, y: Transaction) => x.id.localeCompare(y.id))));
  });
  await ok("রিস্টোর মাঝপথে ব্যর্থ হলে আগের ডেটা অক্ষত (rollback)", async () => {
    const before = await db.transactions.count();
    const bad = validateBackupText(text);
    // ইচ্ছাকৃতভাবে ক্ষতিগ্রস্ত: duplicate key ঢুকিয়ে bulkAdd ব্যর্থ করানো (যাচাইয়ের পরের ধাপ)
    bad.data.transactions.push({ ...bad.data.transactions[0] });
    await assert.rejects(() => restoreBackup(bad));
    assert.equal(await db.transactions.count(), before);
    assert.equal(await db.debts.count(), 1);
  });

  await ok("অচেনা পেমেন্ট মাধ্যমসহ ব্যাকআপ প্রত্যাখ্যাত", () => {
    const b = JSON.parse(text);
    b.data.transactions[0].paymentMethod = "xyz";
    assert.throws(() => validateBackupText(JSON.stringify(b)), (e: unknown) => e instanceof BackupError && e.code === "invalid");
  });
  await ok("ব্যাকআপে ডিফল্ট খাত না থাকলেও রিস্টোরের পর সব ডিফল্ট খাত থাকে", async () => {
    const b = JSON.parse(text);
    const used = new Set(b.data.transactions.map((t: Transaction) => t.categoryId));
    b.data.categories = b.data.categories.filter((c: { id: string }) => used.has(c.id));
    await restoreBackup(validateBackupText(JSON.stringify(b)));
    assert.equal(await db.categories.count(), DEFAULT_CATEGORIES.length);
  });

  console.log("বেতন-মাস (মাসের শুরুর তারিখ)");
  await ok("periodKeyOf / periodRange", () => {
    assert.equal(normalizeStartDay(25), 25);
    assert.equal(normalizeStartDay(0), 1);
    assert.equal(normalizeStartDay(29), 1);
    assert.equal(normalizeStartDay("x"), 1);
    assert.deepEqual(periodRange("2026-11", 1), { from: "2026-11-01", to: "2026-11-30" });
    assert.deepEqual(periodRange("2026-11", 25), { from: "2026-10-25", to: "2026-11-24" });
    assert.deepEqual(periodRange("2027-01", 25), { from: "2026-12-25", to: "2027-01-24" });
    assert.equal(periodKeyOf("2026-10-24", 25), "2026-10");
    assert.equal(periodKeyOf("2026-10-25", 25), "2026-11");
    assert.equal(periodKeyOf("2026-12-31", 25), "2027-01");
    for (const D of [1, 2, 15, 25, 28]) {
      for (const key of ["2026-01", "2026-02", "2026-12", "2028-03"]) {
        const r = periodRange(key, D);
        assert.equal(periodKeyOf(r.from, D), key);
        assert.equal(periodKeyOf(r.to, D), key);
      }
    }
  });
  await ok("বাজেট ও চার্ট শুরুর তারিখ মানে", () => {
    const txs = [tx({ date: "2026-10-24", amount: 1000 }), tx({ date: "2026-10-25", amount: 2000 }), tx({ date: "2026-11-24", amount: 3000 }), tx({ date: "2026-11-25", amount: 5000 })];
    const b: Budget[] = [{ id: "bb", month: "2026-11", categoryId: null, amount: 10000, createdAt: 1, updatedAt: 1 }];
    assert.equal(budgetStatuses(b, txs, "2026-11", 25)[0].spent, 5000);
    assert.equal(budgetStatuses(b, txs, "2026-11")[0].spent, 8000);
    assert.deepEqual(monthlySeries(txs, "2026-10", "2026-12", 25).map((x) => x.expense), [1000, 5000, 5000]);
    assert.deepEqual(monthlySeries(txs, "2026-10", "2026-12").map((x) => x.expense), [3000, 8000, 0]);
  });

  console.log("নিয়মিত লেনদেন ও পিন");
  await ok("নিয়মিত লেনদেনের তারিখ-হিসাব", () => {
    const r = (o: Partial<Recurring> = {}): Recurring => ({ id: "r1", type: "expense", amount: 100, categoryId: "cat_housing", dayOfMonth: 5, startMonth: "2026-05", active: true, createdAt: 0, updatedAt: 0, ...o });
    assert.equal(scheduledDate("2026-02", 31), "2026-02-28");
    assert.equal(scheduledDate("2028-02", 31), "2028-02-29");
    assert.equal(scheduledDate("2026-04", 31), "2026-04-30");
    assert.deepEqual(dueOccurrences(r(), "2026-07-10").map((x) => x.month), ["2026-05", "2026-06", "2026-07"]);
    assert.equal(dueOccurrences(r({ lastMonth: "2026-10" }), "2026-11-03").length, 0);
    assert.equal(dueOccurrences(r({ lastMonth: "2026-10" }), "2026-11-05").length, 1);
    assert.equal(dueOccurrences(r({ active: false }), "2026-11-10").length, 0);
    assert.equal(dueOccurrences(r({ startMonth: "2020-01" }), "2026-11-30").length, 24);
    assert.deepEqual(dueOccurrences(r({ startMonth: "2026-11", dayOfMonth: 1 }), "2027-02-01").map((x) => x.month), ["2026-11", "2026-12", "2027-01", "2027-02"]);
    assert.equal(defaultStartMonth(25, "2026-11-03"), "2026-11");
    assert.equal(defaultStartMonth(2, "2026-12-20"), "2027-01");
  });
  await ok("পিন হ্যাশ ও যাচাই", async () => {
    const salt = makeSalt();
    const h = await hashPin("1234", salt);
    assert.ok(await verifyPin("1234", salt, h));
    assert.ok(!(await verifyPin("1235", salt, h)));
    assert.equal(normalizePin(" ১২৩৪ "), "1234");
    assert.ok(PIN_RE.test("1234") && PIN_RE.test("123456") && !PIN_RE.test("123") && !PIN_RE.test("1234567"));
  });
  await ok("generateRecurring: তৈরি, ডুপ্লিকেট নয়, মুছলে ফেরে না, সম্পাদনা অক্ষত", async () => {
    await db.recurring.clear();
    const before = await db.transactions.count();
    const rule: Recurring = { id: "rr1", type: "expense", amount: 500000, categoryId: "cat_housing", description: "বাসা ভাড়া", dayOfMonth: 5, startMonth: "2026-08", active: true, createdAt: 1, updatedAt: 1 };
    await db.recurring.add(rule);
    assert.equal(await generateRecurring("2026-10-10"), 3);
    assert.equal(await db.transactions.count(), before + 3);
    assert.equal(await generateRecurring("2026-10-10"), 0);
    const sep = occurrenceId("rr1", "2026-09");
    const oct = occurrenceId("rr1", "2026-10");
    await db.transactions.delete(sep);
    await db.transactions.update(oct, { amount: 600000 });
    assert.equal(await generateRecurring("2026-10-20"), 0);
    assert.equal(await db.transactions.get(sep), undefined);
    assert.equal((await db.transactions.get(oct))?.amount, 600000);
    assert.equal(await generateRecurring("2026-11-05"), 1);
  });
  await ok("ব্যাকআপে নিয়মিত লেনদেন যায় ও ফেরে; পুরনো ব্যাকআপ (recurring ছাড়া) চলে", async () => {
    const b = await buildBackup();
    assert.equal(b.data.recurring.length, 1);
    const text2 = JSON.stringify(b);
    await db.recurring.clear();
    await restoreBackup(validateBackupText(text2));
    assert.equal(await db.recurring.count(), 1);
    const old = JSON.parse(text2);
    delete old.data.recurring;
    assert.deepEqual(validateBackupText(JSON.stringify(old)).data.recurring, []);
  });
  await ok("সব ডেটা মুছলে নিয়মিত লেনদেনও যায়", async () => {
    await eraseAllData();
    assert.equal(await db.recurring.count(), 0);
  });

  console.log("অ্যাকাউন্ট ও ট্রান্সফার");
  await ok("অ্যাকাউন্ট ব্যালেন্স ও ট্রান্সফার (মোট অঙ্ক অপরিবর্তিত)", () => {
    const acc = (id: string, open: number): Account => ({ id, name: id, kind: "cash", openingBalance: open, createdAt: 1, updatedAt: 1 });
    const accounts = [acc("cash", 100000), acc("bank", 500000)];
    const txs = [
      tx({ type: "income", amount: 800000, accountId: "bank" }),
      tx({ type: "expense", amount: 20000, accountId: "cash" }),
      tx({ type: "saving", amount: 50000, accountId: "bank" }),
      tx({ type: "withdraw", amount: 10000, accountId: "bank" }),
      tx({ type: "expense", amount: 5000 }),
    ];
    const transfers: Transfer[] = [{ id: "t1", fromAccountId: "bank", toAccountId: "cash", amount: 100000, date: "2026-11-04", createdAt: 1 }];
    const sm = accountSummary(accounts, txs, transfers);
    const by = Object.fromEntries(sm.rows.map((r) => [r.account.id, r.balance]));
    assert.equal(by.cash, 100000 - 20000 + 100000);
    assert.equal(by.bank, 500000 + 800000 - 50000 + 10000 - 100000);
    assert.equal(sm.unassigned, -5000);
    assert.equal(sm.total, 600000 + sumTx(txs).balance);
  });
  await ok("ব্যাকআপে অ্যাকাউন্ট, ট্রান্সফার ও লেনদেনের accountId যায়-ফেরে", async () => {
    await eraseAllData();
    const now = Date.now();
    await db.accounts.bulkAdd([
      { id: "a1", name: "নগদ", kind: "cash", openingBalance: 100000, createdAt: now, updatedAt: now },
      { id: "a2", name: "ব্যাংক", kind: "bank", openingBalance: 0, createdAt: now, updatedAt: now },
    ]);
    await db.transactions.add({ ...tx({ type: "income", amount: 500000 }), id: "ax1", accountId: "a2" });
    await db.transfers.add({ id: "tr1", fromAccountId: "a2", toAccountId: "a1", amount: 100000, date: "2026-11-04", createdAt: now });
    const text3 = JSON.stringify(await buildBackup());
    await eraseAllData();
    await restoreBackup(validateBackupText(text3));
    assert.equal(await db.accounts.count(), 2);
    assert.equal(await db.transfers.count(), 1);
    assert.equal((await db.transactions.get("ax1"))?.accountId, "a2");
    // অচেনা অ্যাকাউন্ট বা নিজের কাছে ট্রান্সফার প্রত্যাখ্যাত
    const bad = JSON.parse(text3);
    bad.data.transactions[0].accountId = "nope";
    assert.throws(() => validateBackupText(JSON.stringify(bad)), (e: unknown) => e instanceof BackupError);
    const bad2 = JSON.parse(text3);
    bad2.data.transfers[0].toAccountId = bad2.data.transfers[0].fromAccountId;
    assert.throws(() => validateBackupText(JSON.stringify(bad2)), (e: unknown) => e instanceof BackupError);
    // পুরনো ব্যাকআপ (accounts/transfers ছাড়া) চলে
    const old = JSON.parse(text3);
    delete old.data.accounts;
    delete old.data.transfers;
    for (const x of old.data.transactions) delete x.accountId;
    assert.deepEqual(validateBackupText(JSON.stringify(old)).data.accounts, []);
  });
  await ok("সব ডেটা মুছলে অ্যাকাউন্টও যায়", async () => {
    await eraseAllData();
    assert.equal(await db.accounts.count(), 0);
    assert.equal(await db.transfers.count(), 0);
  });

  console.log("মেস মোড");
  await ok("ভাগ (allocate): যোগফল সব সময় ঠিক", () => {
    assert.deepEqual(allocate(100, [1, 1, 1]), [34, 33, 33]);
    assert.deepEqual(allocate(0, [1, 2]), [0, 0]);
    assert.deepEqual(allocate(100, [0, 0]), [0, 0]);
    assert.deepEqual(allocate(10, [3, 0, 7]), [3, 0, 7]);
    for (let i = 0; i < 2000; i++) {
      const w = Array.from({ length: 1 + Math.floor(Math.random() * 8) }, () => Math.floor(Math.random() * 40));
      const total = Math.floor(Math.random() * 1e9);
      const a = allocate(total, w);
      assert.equal(a.reduce((x, y) => x + y, 0), w.reduce((x, y) => x + y, 0) > 0 ? total : 0);
    }
    assert.equal(allocate(999_999_999_999, [3, 3, 3, 1]).reduce((x, y) => x + y, 0), 999_999_999_999);
  });
  await ok("মেসের মাসিক হিসাব: মিল-রেট, সাধারণ ভাগ, ব্যালেন্স ও পুল", () => {
    const mem = (id: string, active = true): MessMember => ({ id, name: id, active, createdAt: 1, updatedAt: 1 });
    const meal = (d: string, memberId: string, halves: number): MessMeal => ({ id: mealId(d, memberId), date: d, memberId, halves, updatedAt: 1 });
    const ent = (o: Partial<MessEntry>): MessEntry => ({ id: newId(), kind: "bazaar", amount: 100, date: "2026-11-03", createdAt: 1, ...o });
    const members = [mem("a"), mem("b"), mem("c"), mem("old", false)];
    const meals = [meal("2026-11-01", "a", 2), meal("2026-11-01", "b", 2), meal("2026-11-02", "a", 4), meal("2026-11-02", "c", 1), meal("2026-10-30", "b", 2)];
    const entries = [
      ent({ kind: "deposit", memberId: "a", amount: 100000 }),
      ent({ kind: "deposit", memberId: "b", amount: 50000 }),
      ent({ kind: "bazaar", memberId: "a", amount: 30000 }),
      ent({ kind: "bazaar", amount: 20000 }),
      ent({ kind: "shared", memberId: "c", amount: 90000 }),
      ent({ kind: "bazaar", amount: 99999, date: "2026-10-31" }),
    ];
    const sm = messSummary(members, meals, entries, "2026-11");
    assert.deepEqual(sm.rows.map((r) => r.member.id), ["a", "b", "c"]);
    assert.equal(sm.totalBazaar, 50000);
    assert.equal(sm.totalShared, 90000);
    assert.equal(sm.totalHalves, 9);
    assert.equal(sm.rows.reduce((x, r) => x + r.mealCost, 0), 50000);
    assert.deepEqual(sm.rows.map((r) => r.shared), [30000, 30000, 30000]);
    assert.equal(sm.pool, 150000 + 30000 + 90000 - 50000 - 90000);
    assert.equal(messSummary(members, [...meals, meal("2026-11-05", "old", 2)], entries, "2026-11").rows.some((r) => r.member.id === "old"), true);
    assert.equal(messSummary(members, [], entries, "2026-11").noMeals, true);
  });
  await ok("মেসের ডেটা ব্যাকআপে যায়-ফেরে; অবৈধ সদস্য-রেফারেন্স প্রত্যাখ্যাত; পুরনো ব্যাকআপ চলে", async () => {
    await eraseAllData();
    const now = Date.now();
    await db.messMembers.bulkAdd([
      { id: "m1", name: "রাকিব", active: true, createdAt: now, updatedAt: now },
      { id: "m2", name: "করিম", active: true, createdAt: now, updatedAt: now },
    ]);
    await db.messMeals.add({ id: mealId("2026-11-01", "m1"), date: "2026-11-01", memberId: "m1", halves: 3, updatedAt: now });
    await db.messEntries.bulkAdd([
      { id: "e1", kind: "deposit", memberId: "m1", amount: 100000, date: "2026-11-01", createdAt: now },
      { id: "e2", kind: "bazaar", amount: 30000, date: "2026-11-02", createdAt: now },
    ]);
    const text5 = JSON.stringify(await buildBackup());
    await eraseAllData();
    assert.equal(await db.messMembers.count(), 0);
    await restoreBackup(validateBackupText(text5));
    assert.equal(await db.messMembers.count(), 2);
    assert.equal(await db.messMeals.count(), 1);
    assert.equal(await db.messEntries.count(), 2);
    const bad = JSON.parse(text5);
    bad.data.messMeals[0].memberId = "nope";
    assert.throws(() => validateBackupText(JSON.stringify(bad)), (e: unknown) => e instanceof BackupError);
    const bad2 = JSON.parse(text5);
    delete bad2.data.messEntries.find((x: MessEntry) => x.kind === "deposit").memberId;
    assert.throws(() => validateBackupText(JSON.stringify(bad2)), (e: unknown) => e instanceof BackupError);
    const old = JSON.parse(text5);
    delete old.data.messMembers;
    delete old.data.messMeals;
    delete old.data.messEntries;
    assert.deepEqual(validateBackupText(JSON.stringify(old)).data.messMembers, []);
    await eraseAllData();
  });

  await ok("মেস: সাধারণ খরচ নির্দিষ্ট সদস্যদের মধ্যে ভাগ (splitWith)", () => {
    const mem = (id: string): MessMember => ({ id, name: id, active: true, createdAt: 1, updatedAt: 1 });
    const meals: MessMeal[] = ["a", "b", "c"].map((m) => ({ id: mealId("2026-11-01", m), date: "2026-11-01", memberId: m, halves: 2, updatedAt: 1 }));
    const sh = (o: Partial<MessEntry>): MessEntry => ({ id: newId(), kind: "shared", amount: 100, date: "2026-11-03", createdAt: 1, ...o });
    const sm = messSummary([mem("a"), mem("b"), mem("c")], meals, [sh({ amount: 90000 }), sh({ amount: 10001, splitWith: ["a", "b"] })], "2026-11");
    const by = Object.fromEntries(sm.rows.map((r) => [r.member.id, r.shared]));
    assert.equal(by.a + by.b + by.c, 100001);
    assert.equal(by.c, 30000);
    const fb = messSummary([mem("a"), mem("b")], [], [sh({ amount: 300, splitWith: ["zzz"] })], "2026-11");
    assert.deepEqual(fb.rows.map((r) => r.shared), [150, 150]);
  });

  console.log("দোকান মোড");
  await ok("দোকানের হিসাব: বিক্রি/ক্রয়/খরচ/লাভ, ক্যাশ, বাকি", () => {
    const P = (id: string, kind: "customer" | "supplier"): ShopParty => ({ id, name: id, kind, createdAt: 1, updatedAt: 1 });
    const E = (o: Partial<ShopEntry>): ShopEntry => ({ id: newId(), kind: "sale", amount: 1000, date: "2026-11-03", createdAt: 1, ...o });
    const parties = [P("c1", "customer"), P("c2", "customer"), P("s1", "supplier")];
    const entries = [
      E({ kind: "sale", amount: 5000 }),
      E({ kind: "sale", amount: 3000, paidAmount: 1000, partyId: "c1" }),
      E({ kind: "sale", amount: 2000, paidAmount: 0, partyId: "c2" }),
      E({ kind: "receive", amount: 500, partyId: "c1" }),
      E({ kind: "purchase", amount: 4000, paidAmount: 1500, partyId: "s1" }),
      E({ kind: "pay", amount: 1000, partyId: "s1" }),
      E({ kind: "expense", amount: 700, category: "ভাড়া" }),
      E({ kind: "sale", amount: 900, date: "2026-10-31" }),
    ];
    assert.equal(paidOf(entries[1]), 1000);
    assert.equal(creditOf(entries[1]), 2000);
    const bal = Object.fromEntries(partyBalances(parties, entries).map((b) => [b.party.id, b.balance]));
    assert.deepEqual([bal.c1, bal.c2, bal.s1], [1500, 2000, 1500]);
    const m = shopSummary(entries, parties, "2026-11-01", "2026-11-30");
    assert.equal(m.sales, 10000);
    assert.equal(m.profit, 10000 - 4000 - 700);
    assert.equal(m.cash, 5000 + 1000 + 500 - 1500 - 1000 - 700 + 900);
    assert.equal(m.customerDue, 3500);
    assert.equal(m.supplierDue, 1500);
    const pm = new Map(parties.map((p) => [p.id, p]));
    assert.ok(shopEntryValid(entries[1], pm));
    assert.ok(!shopEntryValid(E({ kind: "sale", amount: 100, paidAmount: 0 }), pm));
    assert.ok(!shopEntryValid(E({ kind: "receive", amount: 100, partyId: "s1" }), pm));
    assert.ok(!shopEntryValid(E({ kind: "sale", amount: 100, paidAmount: 200, partyId: "c1" }), pm));
    assert.equal(parseAmountOrZero(""), 0);
    assert.equal(parseAmountOrZero("০"), 0);
    assert.equal(parseAmountOrZero("abc"), null);
  });
  await ok("দোকানের ডেটা ব্যাকআপে যায়-ফেরে; অবৈধ এন্ট্রি প্রত্যাখ্যাত; পুরনো ব্যাকআপ চলে", async () => {
    await eraseAllData();
    const now = Date.now();
    await db.shopParties.bulkAdd([
      { id: "p1", name: "রহিম", kind: "customer", phone: "01700000000", createdAt: now, updatedAt: now },
      { id: "p2", name: "সরবরাহকারী", kind: "supplier", createdAt: now, updatedAt: now },
    ]);
    await db.shopEntries.bulkAdd([
      { id: "se1", kind: "sale", amount: 300000, paidAmount: 100000, partyId: "p1", date: "2026-11-02", createdAt: now },
      { id: "se2", kind: "expense", amount: 50000, category: "দোকান ভাড়া", date: "2026-11-02", createdAt: now },
    ]);
    const text6 = JSON.stringify(await buildBackup());
    await eraseAllData();
    assert.equal(await db.shopEntries.count(), 0);
    await restoreBackup(validateBackupText(text6));
    assert.equal(await db.shopParties.count(), 2);
    assert.equal(await db.shopEntries.count(), 2);
    const bad = JSON.parse(text6);
    bad.data.shopEntries[0].partyId = "p2"; // বিক্রিতে সরবরাহকারী — ভুল ধরন
    assert.throws(() => validateBackupText(JSON.stringify(bad)), (e: unknown) => e instanceof BackupError);
    const bad2 = JSON.parse(text6);
    bad2.data.shopEntries[0].paidAmount = 999999999; // মোটের বেশি নগদ
    assert.throws(() => validateBackupText(JSON.stringify(bad2)), (e: unknown) => e instanceof BackupError);
    const old = JSON.parse(text6);
    delete old.data.shopParties;
    delete old.data.shopEntries;
    assert.deepEqual(validateBackupText(JSON.stringify(old)).data.shopEntries, []);
    await eraseAllData();
  });

  console.log("সঞ্চয়ের লক্ষ্য, রিমাইন্ডার, জের, গড় ক্রয়দাম");
  await ok("সঞ্চয়ের লক্ষ্য: জমা − তোলা, শতাংশ, প্রতি মাসে কত লাগবে", () => {
    const G = (o: Partial<Goal> = {}): Goal => ({ id: "g1", name: "বাইক", target: 8000000, createdAt: 1, updatedAt: 1, ...o });
    const txs = [tx({ type: "saving", amount: 2000000, goalId: "g1" }), tx({ type: "saving", amount: 500000, goalId: "g1" }), tx({ type: "withdraw", amount: 300000, goalId: "g1" }), tx({ type: "saving", amount: 999, goalId: "other" }), tx({ type: "expense", amount: 5000, goalId: "g1" })];
    let p = goalProgress(G(), txs, "2026-11-10");
    assert.equal(p.saved, 2200000);
    assert.equal(p.percent, 27);
    assert.equal(p.monthsLeft, null);
    p = goalProgress(G({ deadline: "2027-04-30" }), txs, "2026-11-10");
    assert.equal(p.monthsLeft, 6);
    assert.equal(p.neededPerMonth, Math.ceil(5800000 / 6));
    assert.equal(goalProgress(G({ deadline: "2026-10-01" }), txs, "2026-11-10").overdue, true);
    assert.equal(goalProgress(G({ target: 2200000 }), txs, "2026-11-10").done, true);
    assert.equal(goalProgress(G(), [tx({ type: "withdraw", amount: 5, goalId: "g1" })], "2026-11-10").saved, 0);
  });
  await ok("রিমাইন্ডার: আসন্ন বিল/কিস্তি ও ঋণ (আয় বাদ, শোধ-হওয়া বাদ, মেয়াদ-পারও আসে)", () => {
    const R = (o: Partial<Recurring>): Recurring => ({ id: "r1", type: "expense", amount: 800000, categoryId: "cat_housing", description: "ভাড়া", dayOfMonth: 5, startMonth: "2026-05", active: true, createdAt: 0, updatedAt: 0, ...o });
    assert.equal(nextRecurringDate(R({}), "2026-11-03"), "2026-11-05");
    assert.equal(nextRecurringDate(R({}), "2026-11-06"), "2026-12-05");
    assert.equal(nextRecurringDate(R({ lastMonth: "2026-11" }), "2026-11-03"), "2026-12-05");
    const D = (o: Partial<Debt>): Debt => ({ id: "d1", person: "করিম", amount: 100000, kind: "borrowed", date: "2026-10-01", createdAt: 1, updatedAt: 1, ...o });
    const reps: Repayment[] = [{ id: "p1", debtId: "d2", amount: 50000, date: "2026-11-01", createdAt: 1 } as Repayment];
    const rem = upcomingReminders([R({}), R({ id: "r2", type: "income", dayOfMonth: 4 }), R({ id: "r3", dayOfMonth: 20 })], [D({ dueDate: "2026-11-04" }), D({ id: "d2", kind: "lent", amount: 50000, dueDate: "2026-11-01" })], reps, "2026-11-03", 3);
    assert.deepEqual(rem.map((r) => [r.id, r.daysLeft]), [["debt:d1", 1], ["rec:r1", 2]]);
    assert.equal(upcomingReminders([], [D({ dueDate: "2026-10-25" })], [], "2026-11-03", 3)[0].daysLeft, -9);
  });
  await ok("মেসের জের: আগের মাসের বাকি পরের মাসে; মিটিয়ে দিলে শূন্য থেকে শুরু", () => {
    const mem = (id: string): MessMember => ({ id, name: id, active: true, createdAt: 1, updatedAt: 1 });
    const meal = (d: string, m: string, h: number): MessMeal => ({ id: mealId(d, m), date: d, memberId: m, halves: h, updatedAt: 1 });
    const ent = (o: Partial<MessEntry>): MessEntry => ({ id: newId(), kind: "bazaar", amount: 100, date: "2026-10-03", createdAt: 1, ...o });
    const members = [mem("a"), mem("b")];
    const meals = [meal("2026-10-01", "a", 2), meal("2026-10-01", "b", 2), meal("2026-11-01", "a", 2), meal("2026-11-01", "b", 2)];
    const entries = [ent({ kind: "deposit", memberId: "a", amount: 60000, date: "2026-10-02" }), ent({ kind: "deposit", memberId: "b", amount: 20000, date: "2026-10-02" }), ent({ amount: 50000, date: "2026-10-05" }), ent({ amount: 30000, date: "2026-11-05" })];
    assert.deepEqual(messSummary(members, meals, entries, "2026-11").rows.map((r) => r.balance), [-15000, -15000]);
    const carry = messCarryChain(members, meals, entries, "2026-11");
    assert.equal(carry.get("a"), 35000);
    assert.equal(carry.get("b"), -5000);
    assert.deepEqual(messSummary(members, meals, entries, "2026-11", carry).rows.map((r) => r.balance), [20000, -20000]);
    assert.equal(messCarryChain(members, meals, entries, "2026-11", "2026-10").size, 0);
  });
  await ok("দোকান: গড় ক্রয়দামে লাভ (সরল হিসাব অপরিবর্তিত), সেরা পণ্য, বাকির বয়স", () => {
    const P = (id: string, o: Partial<ShopProduct> = {}): ShopProduct => ({ id, name: id, unit: "kg", buyPrice: 0, sellPrice: 0, openingStock: 0, minStock: 0, createdAt: 1, updatedAt: 1, ...o });
    const E = (o: Partial<ShopEntry>): ShopEntry => ({ id: newId(), kind: "sale", amount: 100, date: "2026-11-03", createdAt: 1, ...o });
    const products = [P("rice", { openingStock: 10000, buyPrice: 6000 })];
    const se = [
      E({ kind: "purchase", productId: "rice", qty: 10000, amount: 80000, date: "2026-11-01" }),
      E({ kind: "sale", productId: "rice", qty: 5000, amount: 50000, date: "2026-11-02" }),
      E({ kind: "sale", amount: 20000, date: "2026-11-02" }),
      E({ kind: "purchase", amount: 10000, date: "2026-11-02" }),
      E({ kind: "expense", amount: 5000, date: "2026-11-02" }),
    ];
    assert.equal(cogsOf(costBasis(products, se).get("rice"), 5000, 6000), 35000);
    const ap = shopProfitAvg(se, products, "2026-11-01", "2026-11-30");
    assert.equal(ap.profit, 70000 - 35000 - 10000 - 5000);
    assert.equal(shopSummary(se, [], "2026-11-01", "2026-11-30").profit, 70000 - 90000 - 5000);
    assert.equal(topProducts([E({ productId: "rice", qty: 1000, amount: 5000 })], products, null, null)[0].revenue, 5000);
    const ag = [E({ kind: "sale", amount: 1000, paidAmount: 0, partyId: "c1", date: "2026-10-01" }), E({ kind: "sale", amount: 500, paidAmount: 0, partyId: "c1", date: "2026-10-20" }), E({ kind: "receive", amount: 1000, partyId: "c1", date: "2026-11-01" })];
    assert.equal(oldestDue("c1", ag), "2026-10-20");
    assert.equal(dueAgeDays("c1", ag, "2026-11-10"), 21);
  });
  await ok("AI: খরচের বিবরণ বন্ধ থাকলে নিজের লেখা পাঠানো হয় না", () => {
    const secret = "রহিমের বিয়ের উপহার";
    const dataB = { transactions: [tx({ type: "expense", amount: 900000, description: secret, date: todayDhaka() })], categories: DEFAULT_CATEGORIES, budgets: [], debts: [], repayments: [] };
    assert.ok(buildFacts(dataB, todayDhaka(), "bn", "bn", 1, true).includes(secret));
    assert.ok(!buildFacts(dataB, todayDhaka(), "bn", "bn", 1, false).includes(secret));
  });
  await ok("লক্ষ্য ও লক্ষ্যের লেনদেন ব্যাকআপে যায়-ফেরে; অচেনা লক্ষ্য প্রত্যাখ্যাত; পুরনো ব্যাকআপ চলে", async () => {
    await eraseAllData();
    const now = Date.now();
    await db.goals.add({ id: "gl1", name: "বাইক", target: 8000000, deadline: "2027-06-30", createdAt: now, updatedAt: now });
    await db.transactions.add(tx({ id: "gt1", type: "saving", amount: 500000, categoryId: "cat_saving", goalId: "gl1" }));
    const text10 = JSON.stringify(await buildBackup());
    await eraseAllData();
    await restoreBackup(validateBackupText(text10));
    assert.equal((await db.goals.get("gl1"))?.target, 8000000);
    assert.equal((await db.transactions.get("gt1"))?.goalId, "gl1");
    const bad = JSON.parse(text10);
    bad.data.transactions.find((x: Transaction) => x.id === "gt1").goalId = "nope";
    assert.throws(() => validateBackupText(JSON.stringify(bad)), (e: unknown) => e instanceof BackupError);
    const old = JSON.parse(text10);
    delete old.data.goals;
    for (const x of old.data.transactions) delete x.goalId;
    assert.deepEqual(validateBackupText(JSON.stringify(old)).data.goals, []);
    await eraseAllData();
  });

  console.log("মেসের বাজেট");
  await ok("মেসের বাজেট: খরচ = বাজার + সাধারণ খরচ; সতর্কতা; দৈনিক সীমা; পূর্বাভাস", () => {
    const mem = (id: string): MessMember => ({ id, name: id, active: true, createdAt: 1, updatedAt: 1 });
    const ent = (o: Partial<MessEntry>): MessEntry => ({ id: newId(), kind: "bazaar", amount: 100, date: "2026-11-03", createdAt: 1, ...o });
    const members = [mem("a"), mem("b"), mem("c"), mem("d")];
    const entries = [ent({ amount: 600000 }), ent({ kind: "shared", amount: 800000, note: "ভাড়া" }), ent({ kind: "deposit", memberId: "a", amount: 2000000 })];
    const sm = messSummary(members, [], entries, "2026-11");
    const b = messBudgetStatus(sm, 2000000, "2026-11", "2026-11-10");
    assert.equal(b.spent, 1400000);
    assert.equal(b.remaining, 600000);
    assert.equal(b.percent, 70);
    assert.equal(b.level, "ok");
    assert.equal(b.daysLeft, 21);
    assert.equal(b.dailyAllowance, Math.floor(600000 / 21));
    assert.equal(b.projected, 1400000 + 1200000);
    assert.equal(b.willExceed, true);
    assert.equal(b.perMember, 500000);
    assert.equal(messBudgetStatus(sm, 1400000, "2026-11", "2026-11-10").level, "warn");
    assert.equal(messBudgetStatus(sm, 1399999, "2026-11", "2026-11-10").level, "over");
    assert.equal(messBudgetStatus(sm, 2000000, "2026-11", "2026-11-03").projectionReady, false);
    assert.equal(messBudgetStatus(sm, 2000000, "2026-11", "2026-12-05").daysLeft, 0);
    assert.equal(messBudgetStatus(sm, 100, "2028-02", "2028-02-01").daysInMonth, 29);
  });
  await ok("মেসের খরচ খাত অনুযায়ী (নিজের লেখা নামসহ)", () => {
    const e = (o: Partial<MessEntry>): MessEntry => ({ id: newId(), kind: "shared", amount: 100, date: "2026-11-03", createdAt: 1, ...o });
    const rows = messCostBreakdown([e({ amount: 800000, note: "বাড়ি ভাড়া" }), e({ amount: 120000, note: "বিদ্যুৎ" }), e({ amount: 30000, note: "বিদ্যুৎ " }), e({ kind: "bazaar", amount: 650000 }), e({ kind: "deposit", memberId: "a", amount: 9999999 })], "2026-11");
    assert.deepEqual(rows.map((r) => [r.kind, r.label, r.amount]), [["shared", "বাড়ি ভাড়া", 800000], ["bazaar", null, 650000], ["shared", "বিদ্যুৎ", 150000]]);
  });
  await ok("মেসের বাজেট ব্যাকআপে যায়-ফেরে; পুরনো ব্যাকআপ চলে", async () => {
    await eraseAllData();
    const now = Date.now();
    await db.messBudgets.bulkAdd([
      { id: "2026-11", month: "2026-11", amount: 2000000, createdAt: now, updatedAt: now },
      { id: "2026-10", month: "2026-10", amount: 1800000, createdAt: now, updatedAt: now },
    ]);
    const text9 = JSON.stringify(await buildBackup());
    await eraseAllData();
    assert.equal(await db.messBudgets.count(), 0);
    await restoreBackup(validateBackupText(text9));
    assert.equal((await db.messBudgets.get("2026-11"))?.amount, 2000000);
    const bad = JSON.parse(text9);
    bad.data.messBudgets[0].id = "2020-01";
    assert.throws(() => validateBackupText(JSON.stringify(bad)), (e: unknown) => e instanceof BackupError);
    const old = JSON.parse(text9);
    delete old.data.messBudgets;
    assert.deepEqual(validateBackupText(JSON.stringify(old)).data.messBudgets, []);
    await eraseAllData();
  });

  console.log("পণ্য ও স্টক");
  await ok("পরিমাণ পার্স/ফরম্যাট ও লাইন-মোট (ভাসমান-সংখ্যার ভুল নেই)", () => {
    assert.equal(parseQty("2.5"), 2500);
    assert.equal(parseQty("২.৫"), 2500);
    assert.equal(parseQty("0.001"), 1);
    assert.equal(parseQty("0"), null);
    assert.equal(parseQty("1.2345"), null);
    assert.equal(parseQtyOrZero(""), 0);
    assert.equal(parseQty("0.1")! + parseQty("0.2")!, 300);
    assert.equal(formatQty(2500), "2.5");
    assert.equal(formatQty(-500), "-0.5");
    assert.equal(lineTotal(2500, 12000), 30000);
    assert.equal(lineTotal(500, 1), 1);
    assert.equal(lineTotal(MAX_QTY, 999_999_999_999), null);
  });
  await ok("স্টক = শুরুর + ক্রয় − বিক্রি ± সংশোধন; কম/শেষ সতর্কতা; মূল্য", () => {
    const P = (id: string, o: Partial<ShopProduct> = {}): ShopProduct => ({ id, name: id, unit: "kg", buyPrice: 0, sellPrice: 0, openingStock: 0, minStock: 0, createdAt: 1, updatedAt: 1, ...o });
    const E = (o: Partial<ShopEntry>): ShopEntry => ({ id: newId(), kind: "sale", amount: 100, date: "2026-11-03", createdAt: 1, ...o });
    const A = (productId: string, delta: number): ShopAdjustment => ({ id: newId(), productId, delta, date: "2026-11-03", createdAt: 1 });
    const products = [P("rice", { openingStock: 10000, buyPrice: 6000, minStock: 5000 }), P("oil", { openingStock: 2000, minStock: 1000 }), P("salt"), P("sugar", { openingStock: 3000, buyPrice: 10000 })];
    const entries = [E({ kind: "purchase", productId: "rice", qty: 5000 }), E({ kind: "sale", productId: "rice", qty: 8500 }), E({ kind: "sale", productId: "oil", qty: 1500 }), E({ kind: "sale", productId: "salt", qty: 1000 }), E({ kind: "sale", amount: 5 })];
    const sm = stockSummary(products, entries, [A("rice", -500), A("sugar", 250)]);
    const r = Object.fromEntries(sm.rows.map((x) => [x.product.id, x]));
    assert.equal(r.rice.stock, 6000);
    assert.equal(r.rice.low, false);
    assert.equal(r.oil.stock, 500);
    assert.equal(r.oil.low, true);
    assert.equal(r.salt.stock, -1000);
    assert.equal(r.salt.out, true);
    assert.equal(r.sugar.value, lineTotal(3250, 10000));
    assert.equal(sm.lowCount, 1);
    assert.equal(sm.outCount, 0);
    const pm = new Map<string, ShopParty>();
    const ids = new Set(["rice"]);
    assert.ok(shopEntryValid(E({ kind: "sale", productId: "rice", qty: 1000 }), pm, ids));
    assert.ok(!shopEntryValid(E({ kind: "sale", productId: "rice" }), pm, ids));
    assert.ok(!shopEntryValid(E({ kind: "sale", productId: "ghost", qty: 1000 }), pm, ids));
    assert.ok(!shopEntryValid(E({ kind: "expense", productId: "rice", qty: 1000 }), pm, ids));
  });
  await ok("পণ্য, স্টক-সংশোধন ও এন্ট্রির পণ্য-লিংক ব্যাকআপে যায়-ফেরে; অবৈধ রেফারেন্স প্রত্যাখ্যাত; পুরনো ব্যাকআপ চলে", async () => {
    await eraseAllData();
    const now = Date.now();
    await db.shopProducts.add({ id: "pr1", name: "চাল", unit: "kg", buyPrice: 6000, sellPrice: 7000, openingStock: 10000, minStock: 2000, createdAt: now, updatedAt: now });
    await db.shopAdjustments.add({ id: "ad1", productId: "pr1", delta: -500, date: "2026-11-02", note: "নষ্ট", createdAt: now });
    await db.shopEntries.add({ id: "pe1", kind: "sale", amount: 21000, productId: "pr1", qty: 3000, date: "2026-11-03", createdAt: now });
    const text8 = JSON.stringify(await buildBackup());
    await eraseAllData();
    assert.equal(await db.shopProducts.count(), 0);
    await restoreBackup(validateBackupText(text8));
    assert.equal(await db.shopProducts.count(), 1);
    assert.equal(await db.shopAdjustments.count(), 1);
    assert.equal((await db.shopEntries.get("pe1"))?.qty, 3000);
    const bad = JSON.parse(text8);
    bad.data.shopEntries[0].productId = "nope";
    assert.throws(() => validateBackupText(JSON.stringify(bad)), (e: unknown) => e instanceof BackupError);
    const bad2 = JSON.parse(text8);
    bad2.data.shopAdjustments[0].productId = "nope";
    assert.throws(() => validateBackupText(JSON.stringify(bad2)), (e: unknown) => e instanceof BackupError);
    const bad3 = JSON.parse(text8);
    delete bad3.data.shopEntries[0].qty;
    assert.throws(() => validateBackupText(JSON.stringify(bad3)), (e: unknown) => e instanceof BackupError);
    const old = JSON.parse(text8);
    delete old.data.shopProducts;
    delete old.data.shopAdjustments;
    old.data.shopEntries = [];
    assert.deepEqual(validateBackupText(JSON.stringify(old)).data.shopProducts, []);
    await eraseAllData();
  });

  console.log("অফিস খরচ ফেরত");
  await ok("ফেরত পাওয়া ও বাতিল; দুইবার চাপলে ডুপ্লিকেট নয়; ব্যালেন্স অপরিবর্তিত", async () => {
    await eraseAllData();
    const base = tx({ id: "rx1", amount: 250000, description: "অফিস ট্যুর", reimbursable: true, date: "2026-11-02" });
    await db.transactions.bulkAdd([base, tx({ id: "rx2", amount: 100, reimbursable: false })]);
    let all = await db.transactions.toArray();
    assert.equal(all.filter(isPending).length, 1);
    assert.equal(pendingTotal(all), 250000);
    assert.equal(await markReceived("rx1", "2026-11-09", undefined, "ফেরত"), true);
    const inc = await db.transactions.get(reimbursementIncomeId("rx1"));
    assert.equal(inc?.type, "income");
    assert.equal(inc?.amount, 250000);
    assert.equal(inc?.categoryId, REIMBURSEMENT_CATEGORY_ID);
    assert.ok(await db.categories.get(REIMBURSEMENT_CATEGORY_ID));
    all = await db.transactions.toArray();
    assert.equal(all.filter(isReceived).length, 1);
    assert.equal(await markReceived("rx1", "2026-11-10", undefined, "ফেরত"), false);
    assert.equal(all.filter((x) => x.id.startsWith("reimb_")).length, 1);
    assert.equal(await undoReceived("rx1"), true);
    assert.equal(await db.transactions.get(reimbursementIncomeId("rx1")), undefined);
    assert.equal((await db.transactions.get("rx1"))?.reimbursedAt, undefined);
    assert.equal((await db.transactions.toArray()).filter(isPending).length, 1);
  });
  await ok("ব্যাকআপে ফেরতের তথ্য যায়-ফেরে", async () => {
    await eraseAllData();
    await db.transactions.add(tx({ id: "rb1", amount: 5000, reimbursable: true }));
    await markReceived("rb1", "2026-11-09", undefined, "ফেরত");
    const text7 = JSON.stringify(await buildBackup());
    await eraseAllData();
    await restoreBackup(validateBackupText(text7));
    assert.equal((await db.transactions.get("rb1"))?.reimbursedAt, "2026-11-09");
    assert.ok(await db.transactions.get(reimbursementIncomeId("rb1")));
    assert.ok(await db.categories.get(REIMBURSEMENT_CATEGORY_ID));
    await eraseAllData();
  });

  console.log("লক্ষ্য, রিমাইন্ডার, জের ও গড় লাভ");
  await ok("সঞ্চয়ের লক্ষ্য: জমা − উত্তোলন, শতাংশ, মাসে কত লাগবে", () => {
    const G = (o: Partial<Goal> = {}): Goal => ({ id: "g1", name: "বাইক", target: 8000000, createdAt: 1, updatedAt: 1, ...o });
    const txs = [tx({ type: "saving", amount: 2000000, goalId: "g1" }), tx({ type: "saving", amount: 500000, goalId: "g1" }), tx({ type: "withdraw", amount: 300000, goalId: "g1" }), tx({ type: "saving", amount: 999999, goalId: "other" }), tx({ type: "expense", amount: 5000, goalId: "g1" })];
    let p = goalProgress(G(), txs, "2026-11-10");
    assert.equal(p.saved, 2200000);
    assert.equal(p.percent, 27);
    p = goalProgress(G({ deadline: "2027-04-30" }), txs, "2026-11-10");
    assert.equal(p.monthsLeft, 6);
    assert.equal(p.neededPerMonth, Math.ceil(5800000 / 6));
    assert.equal(goalProgress(G({ deadline: "2026-10-01" }), txs, "2026-11-10").overdue, true);
    assert.equal(goalProgress(G({ target: 2200000 }), txs, "2026-11-10").done, true);
    assert.equal(goalProgress(G(), [tx({ type: "withdraw", amount: 5, goalId: "g1" })], "2026-11-10").saved, 0);
  });
  await ok("আসন্ন বিল/কিস্তি/ঋণের রিমাইন্ডার", () => {
    const R = (o: Partial<Recurring> = {}): Recurring => ({ id: "r1", type: "expense", amount: 800000, categoryId: "cat_housing", description: "ভাড়া", dayOfMonth: 5, startMonth: "2026-05", active: true, createdAt: 0, updatedAt: 0, ...o });
    assert.equal(nextRecurringDate(R(), "2026-11-03"), "2026-11-05");
    assert.equal(nextRecurringDate(R(), "2026-11-06"), "2026-12-05");
    assert.equal(nextRecurringDate(R({ lastMonth: "2026-11" }), "2026-11-03"), "2026-12-05");
    assert.equal(nextRecurringDate(R({ active: false }), "2026-11-03"), null);
    const D = (o: Partial<Debt>): Debt => ({ id: "d1", person: "করিম", amount: 100000, kind: "borrowed", date: "2026-10-01", createdAt: 1, updatedAt: 1, ...o });
    const rem = upcomingReminders([R(), R({ id: "r2", type: "income", dayOfMonth: 4 }), R({ id: "r3", dayOfMonth: 20 })], [D({ dueDate: "2026-11-04" }), D({ id: "d3", dueDate: "2026-12-30" }), D({ id: "d4" })], [], "2026-11-03", 3);
    assert.deepEqual(rem.map((r) => [r.id, r.daysLeft]), [["debt:d1", 1], ["rec:r1", 2]]);
    assert.equal(upcomingReminders([], [D({ dueDate: "2026-10-25" })], [], "2026-11-03", 3)[0].daysLeft, -9);
  });
  await ok("মেসের আগের মাসের জের (ডিফল্টে বন্ধ, চালু করলে জমে, মিটিয়ে দিলে শূন্য)", () => {
    const mem = (id: string): MessMember => ({ id, name: id, active: true, createdAt: 1, updatedAt: 1 });
    const meal = (d: string, m: string, h: number): MessMeal => ({ id: mealId(d, m), date: d, memberId: m, halves: h, updatedAt: 1 });
    const ent = (o: Partial<MessEntry>): MessEntry => ({ id: newId(), kind: "bazaar", amount: 100, date: "2026-10-03", createdAt: 1, ...o });
    const members = [mem("a"), mem("b")];
    const meals = [meal("2026-10-01", "a", 2), meal("2026-10-01", "b", 2), meal("2026-11-01", "a", 2), meal("2026-11-01", "b", 2)];
    const entries = [ent({ kind: "deposit", memberId: "a", amount: 60000, date: "2026-10-02" }), ent({ kind: "deposit", memberId: "b", amount: 20000, date: "2026-10-02" }), ent({ amount: 50000, date: "2026-10-05" }), ent({ amount: 30000, date: "2026-11-05" })];
    assert.deepEqual(messSummary(members, meals, entries, "2026-11").rows.map((r) => r.balance), [-15000, -15000]);
    const carry = messCarryChain(members, meals, entries, "2026-11");
    assert.equal(carry.get("a"), 35000);
    assert.equal(carry.get("b"), -5000);
    assert.deepEqual(messSummary(members, meals, entries, "2026-11", carry).rows.map((r) => r.balance), [20000, -20000]);
    assert.equal(messCarryChain(members, meals, entries, "2026-11", "2026-10").size, 0);
  });
  await ok("দোকান: গড় ক্রয়দামে লাভ (সরল হিসাব অপরিবর্তিত), সেরা পণ্য, বাকির বয়স", () => {
    const P = (id: string, o: Partial<ShopProduct> = {}): ShopProduct => ({ id, name: id, unit: "kg", buyPrice: 0, sellPrice: 0, openingStock: 0, minStock: 0, createdAt: 1, updatedAt: 1, ...o });
    const E = (o: Partial<ShopEntry>): ShopEntry => ({ id: newId(), kind: "sale", amount: 100, date: "2026-11-03", createdAt: 1, ...o });
    const products = [P("rice", { openingStock: 10000, buyPrice: 6000 })];
    const se = [
      E({ kind: "purchase", productId: "rice", qty: 10000, amount: 80000, date: "2026-11-01" }),
      E({ kind: "sale", productId: "rice", qty: 5000, amount: 50000, date: "2026-11-02" }),
      E({ kind: "sale", amount: 20000, date: "2026-11-02" }),
      E({ kind: "purchase", amount: 10000, date: "2026-11-02" }),
      E({ kind: "expense", amount: 5000, date: "2026-11-02" }),
    ];
    assert.equal(costBasis(products, se).get("rice")?.cost, 140000);
    assert.equal(cogsOf(costBasis(products, se).get("rice"), 5000, 6000), 35000);
    const ap = shopProfitAvg(se, products, "2026-11-01", "2026-11-30");
    assert.equal(ap.profit, 70000 - 35000 - 10000 - 5000);
    assert.equal(shopSummary(se, [], "2026-11-01", "2026-11-30").profit, 70000 - 90000 - 5000);
    assert.deepEqual(topProducts([E({ productId: "rice", qty: 1000, amount: 5000 }), E({ productId: "rice", qty: 2000, amount: 9000 })], products, null, null).map((x) => [x.qty, x.revenue]), [[3000, 14000]]);
    const ag = [E({ kind: "sale", amount: 1000, paidAmount: 0, partyId: "c1", date: "2026-10-01" }), E({ kind: "sale", amount: 500, paidAmount: 0, partyId: "c1", date: "2026-10-20" }), E({ kind: "receive", amount: 1000, partyId: "c1", date: "2026-11-01" })];
    assert.equal(oldestDue("c1", ag), "2026-10-20");
    assert.equal(dueAgeDays("c1", ag, "2026-11-10"), 21);
  });
  await ok("AI-তে খরচের বিবরণ পাঠানো যায়/বন্ধ রাখা যায়", () => {
    const today = todayDhaka();
    const data = { transactions: [tx({ type: "expense", amount: 555500, description: "গোপন-বিবরণ-XYZ", date: today })], categories: DEFAULT_CATEGORIES, budgets: [], debts: [], repayments: [] };
    assert.ok(buildFacts(data, today, "bn", "en", 1, true).includes("গোপন-বিবরণ-XYZ"));
    assert.ok(buildFacts(data, today, "bn", "en").includes("গোপন-বিবরণ-XYZ"));
    assert.ok(!buildFacts(data, today, "bn", "en", 1, false).includes("গোপন-বিবরণ-XYZ"));
  });
  await ok("লক্ষ্য ও লক্ষ্যে-বাঁধা সঞ্চয় ব্যাকআপে যায়-ফেরে; অচেনা লক্ষ্য প্রত্যাখ্যাত; পুরনো ব্যাকআপ চলে", async () => {
    await eraseAllData();
    const now = Date.now();
    await db.goals.add({ id: "gl1", name: "বাইক", target: 8000000, deadline: "2027-06-30", createdAt: now, updatedAt: now });
    await db.transactions.add({ ...tx({ type: "saving", amount: 500000, categoryId: "cat_saving" }), id: "gt1", goalId: "gl1" });
    const text10 = JSON.stringify(await buildBackup());
    await eraseAllData();
    assert.equal(await db.goals.count(), 0);
    await restoreBackup(validateBackupText(text10));
    assert.equal((await db.goals.get("gl1"))?.target, 8000000);
    assert.equal((await db.transactions.get("gt1"))?.goalId, "gl1");
    const bad = JSON.parse(text10);
    bad.data.transactions.find((x: Transaction) => x.id === "gt1").goalId = "nope";
    assert.throws(() => validateBackupText(JSON.stringify(bad)), (e: unknown) => e instanceof BackupError);
    const old = JSON.parse(text10);
    delete old.data.goals;
    for (const x of old.data.transactions) delete x.goalId;
    assert.deepEqual(validateBackupText(JSON.stringify(old)).data.goals, []);
    await eraseAllData();
  });

  console.log("এনক্রিপ্টেড ব্যাকআপ");
  await ok("এনক্রিপ্ট/ডিক্রিপ্ট; ভুল পাসওয়ার্ড ও বদলানো ফাইল প্রত্যাখ্যাত", async () => {
    const plain = JSON.stringify({ a: "বাংলা ✓", n: 1 });
    const e = await encryptText(plain, "পাসওয়ার্ড-১২৩");
    assert.ok(isEncryptedBackupText(e) && !isEncryptedBackupText(plain));
    assert.ok(!e.includes("বাংলা"));
    assert.equal(await decryptText(e, "পাসওয়ার্ড-১২৩"), plain);
    await assert.rejects(decryptText(e, "ভুল-পাসওয়ার্ড"), (x: unknown) => x instanceof DecryptError && x.code === "wrong");
    const o = JSON.parse(e);
    const bytes = Buffer.from(o.data, "base64");
    bytes[3] ^= 1;
    o.data = bytes.toString("base64");
    await assert.rejects(decryptText(JSON.stringify(o), "পাসওয়ার্ড-১২৩"), (x: unknown) => x instanceof DecryptError && x.code === "wrong");
    await assert.rejects(decryptText("{}", "x"), (x: unknown) => x instanceof DecryptError && x.code === "invalid");
  });
  await ok("এনক্রিপ্টেড ব্যাকআপ থেকে রিস্টোর; সাধারণ ইম্পোর্ট এটি নেয় না", async () => {
    await eraseAllData();
    await db.transactions.add({ ...tx({ amount: 4242 }), id: "enc1", description: "গোপন-বিবরণ" });
    const text4 = await (await encryptedBackupBlob(await buildBackup(), "secret-pass-1")).text();
    assert.ok(isEncryptedBackupText(text4));
    assert.ok(!text4.includes("গোপন-বিবরণ"));
    await eraseAllData();
    await restoreBackup(validateBackupText(await decryptText(text4, "secret-pass-1")));
    assert.equal((await db.transactions.get("enc1"))?.amount, 4242);
    assert.throws(() => validateBackupText(text4), (e: unknown) => e instanceof BackupError);
  });

  console.log(`\nসম্পন্ন: ${n} টি পরীক্ষা চলেছে`, process.exitCode ? "— ব্যর্থতা আছে ✗" : "— সব পাস ✓");
})();
